# online-boosting
Experiments around Online Boosting algorithms (OzaBoost, SmoothBoost, EXPBoost, OCPBoost, OGBoost)<br><br>
Derived a new greedy based online boosting algorithm(GreedyBoost)

Final report: https://github.com/deshanadesai/online-boosting/blob/master/Greedyboost_paper.pdf
